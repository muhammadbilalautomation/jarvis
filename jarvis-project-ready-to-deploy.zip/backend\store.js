'use strict';

const { DatabaseSync } = require('node:sqlite');
const { mkdirSync } = require('node:fs');
const path = require('node:path');

function openStore(filename = path.join(__dirname, '../storage/jarvis.sqlite')) {
  if (filename !== ':memory:') mkdirSync(path.dirname(filename), { recursive: true });
  const db = new DatabaseSync(filename);
  db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS departments(id TEXT PRIMARY KEY,name TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS employees(id TEXT PRIMARY KEY,department_id TEXT NOT NULL REFERENCES departments(id),name TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS customers(id TEXT PRIMARY KEY,name TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS projects(
      id TEXT PRIMARY KEY,department_id TEXT NOT NULL REFERENCES departments(id),name TEXT NOT NULL,
      lead_id TEXT NOT NULL REFERENCES employees(id),budget_cents INTEGER NOT NULL CHECK(budget_cents>=0),
      start_date TEXT NOT NULL,due_date TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS milestones(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),
      name TEXT NOT NULL,due_date TEXT NOT NULL,completed_date TEXT);
    CREATE TABLE IF NOT EXISTS transactions(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),
      employee_id TEXT NOT NULL REFERENCES employees(id),customer_id TEXT REFERENCES customers(id),
      date TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('revenue','expense')),
      amount_cents INTEGER NOT NULL CHECK(amount_cents>=0));
    CREATE INDEX IF NOT EXISTS transaction_date ON transactions(date,project_id);
    CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),
      title TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('open','completed')),
      created_at TEXT NOT NULL,completed_at TEXT);
    CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY,request TEXT NOT NULL,workflow TEXT NOT NULL,
      action TEXT NOT NULL,parameters TEXT NOT NULL,result TEXT NOT NULL,status TEXT NOT NULL,timestamp TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS requests(key TEXT PRIMARY KEY,fingerprint TEXT NOT NULL,response TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS confirmations(token TEXT PRIMARY KEY,action TEXT NOT NULL,expires_at TEXT NOT NULL,used INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS voice_confirmations(token TEXT PRIMARY KEY REFERENCES confirmations(token),call_id TEXT NOT NULL);
  `);
  return db;
}

module.exports = { openStore };
