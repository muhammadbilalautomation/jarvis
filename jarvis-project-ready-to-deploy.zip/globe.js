/**
 * JARVIS 3D Central Core (Electric Blue & White Globe HUD)
 * Supports dynamic switching between Light Mode & Dark Mode
 */

let globeScene, globeCamera, globeRenderer, globeCore, outerRing, innerRing, particleField;
let globeState = "idle";
let clock = null;
let currentGlobeTheme = "light";

function initJarvisGlobe(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const width = container.clientWidth || 320;
  const height = container.clientHeight || 300;

  globeScene = new THREE.Scene();
  globeCamera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
  globeCamera.position.z = 240;

  globeRenderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
  globeRenderer.setSize(width, height);
  globeRenderer.setPixelRatio(window.devicePixelRatio || 1);
  container.innerHTML = "";
  container.appendChild(globeRenderer.domElement);

  const masterGroup = new THREE.Group();
  globeScene.add(masterGroup);

  const sphereGeo = new THREE.SphereGeometry(62, 32, 32);
  const sphereMat = new THREE.MeshBasicMaterial({
    color: 0x0284c7,
    wireframe: true,
    transparent: true,
    opacity: 0.35
  });
  globeCore = new THREE.Mesh(sphereGeo, sphereMat);
  masterGroup.add(globeCore);

  const innerGlowGeo = new THREE.SphereGeometry(58, 24, 24);
  const innerGlowMat = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.15
  });
  const innerGlow = new THREE.Mesh(innerGlowGeo, innerGlowMat);
  masterGroup.add(innerGlow);

  const ringGeo = new THREE.RingGeometry(82, 83.5, 64);
  const ringMat = new THREE.MeshBasicMaterial({
    color: 0x0284c7,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.70
  });
  outerRing = new THREE.Mesh(ringGeo, ringMat);
  outerRing.rotation.x = Math.PI / 3;
  outerRing.rotation.y = Math.PI / 6;
  masterGroup.add(outerRing);

  const innerRingGeo = new THREE.RingGeometry(72, 73, 64);
  const innerRingMat = new THREE.MeshBasicMaterial({
    color: 0x0ea5e9,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.55
  });
  innerRing = new THREE.Mesh(innerRingGeo, innerRingMat);
  innerRing.rotation.x = -Math.PI / 4;
  masterGroup.add(innerRing);

  const particleCount = 450;
  const particleGeo = new THREE.BufferGeometry();
  const positions = new Float32Array(particleCount * 3);

  for (let i = 0; i < particleCount * 3; i += 3) {
    const radius = 64 + Math.random() * 32;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(Math.random() * 2 - 1);
    positions[i] = radius * Math.sin(phi) * Math.cos(theta);
    positions[i + 1] = radius * Math.sin(phi) * Math.sin(theta);
    positions[i + 2] = radius * Math.cos(phi);
  }

  particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const particleMat = new THREE.PointsMaterial({
    color: 0x0369a1,
    size: 1.8,
    transparent: true,
    opacity: 0.75
  });
  particleField = new THREE.Points(particleGeo, particleMat);
  masterGroup.add(particleField);

  clock = new THREE.Clock();

  function animate() {
    requestAnimationFrame(animate);
    const elapsedTime = clock.getElapsedTime();

    if (globeState === "listening") {
      globeCore.rotation.y += 0.035;
      outerRing.rotation.z += 0.025;
      innerRing.rotation.z -= 0.030;
      const scale = 1 + Math.sin(elapsedTime * 6) * 0.05;
      globeCore.scale.set(scale, scale, scale);
      globeCore.material.color.setHex(0x0ea5e9);
    } else if (globeState === "speaking") {
      globeCore.rotation.y += 0.020;
      outerRing.rotation.z += 0.015;
      innerRing.rotation.z -= 0.018;
      const scale = 1 + Math.sin(elapsedTime * 9) * 0.07;
      globeCore.scale.set(scale, scale, scale);
      globeCore.material.color.setHex(0x2563eb);
    } else {
      globeCore.rotation.y += 0.006;
      outerRing.rotation.z += 0.004;
      innerRing.rotation.z -= 0.005;
      globeCore.scale.set(1, 1, 1);
      const defaultColor = currentGlobeTheme === "dark" ? 0x00d2ff : 0x0284c7;
      globeCore.material.color.setHex(defaultColor);
    }

    particleField.rotation.y += 0.003;
    globeRenderer.render(globeScene, globeCamera);
  }

  animate();

  window.addEventListener("resize", () => {
    if (!container) return;
    const w = container.clientWidth || 320;
    const h = container.clientHeight || 300;
    globeCamera.aspect = w / h;
    globeCamera.updateProjectionMatrix();
    globeRenderer.setSize(w, h);
  });
}

function updateGlobeTheme(theme) {
  currentGlobeTheme = theme;
  if (!globeCore) return;
  if (theme === "dark") {
    globeCore.material.color.setHex(0x00d2ff);
    outerRing.material.color.setHex(0xffffff);
    innerRing.material.color.setHex(0x00d2ff);
    particleField.material.color.setHex(0xffffff);
  } else {
    globeCore.material.color.setHex(0x0284c7);
    outerRing.material.color.setHex(0x0284c7);
    innerRing.material.color.setHex(0x0ea5e9);
    particleField.material.color.setHex(0x0369a1);
  }
}

function setGlobeState(state) {
  globeState = state;
  const statusBadge = document.getElementById("jarvis-hud-status");
  if (statusBadge) {
    if (state === "listening") {
      statusBadge.textContent = "LISTENING...";
      statusBadge.className = "text-xs font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 border border-emerald-500/40 animate-pulse font-bold";
    } else if (state === "speaking") {
      statusBadge.textContent = "RESPONDING...";
      statusBadge.className = "text-xs font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-600 dark:text-cyan-300 border border-cyan-500/40 animate-pulse font-bold";
    } else {
      statusBadge.textContent = "CORE READY";
      statusBadge.className = "text-xs font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-600 dark:text-blue-300 border border-blue-500/20 font-bold";
    }
  }
}
