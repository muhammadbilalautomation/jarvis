'use strict';

const http = require('node:http');
const { readFileSync, existsSync } = require('node:fs');
const path = require('node:path');
const { timingSafeEqual } = require('node:crypto');
const { openStore } = require('./store');
const { seed } = require('./seed');
const { createService, UserError } = require('./service');
const { createCommandHandler,createVoiceHandler } = require('./integrations');
const { verifyVoiceSignature } = require('./voice-signature');

const publicFiles = new Map([
  ['/', ['index.html','text/html']], ['/index.html',['index.html','text/html']],
  ['/app.js',['app.js','application/javascript']], ['/data.js',['data.js','application/javascript']],
  ['/charts.js',['charts.js','application/javascript']], ['/globe.js',['globe.js','application/javascript']],
  ['/styles.css',['styles.css','text/css']],
  ...['tailwind.js','three.min.js','echarts.min.js','lucide.js'].map(name=>['/assets/'+name,['assets/'+name,'application/javascript']])
]);
function sameSecret(a,b) { const x=Buffer.from(a),y=Buffer.from(b); return x.length===y.length && timingSafeEqual(x,y); }
function pdfText(value='') { return String(value).replace(/[\\()]/g,'\\$&').replace(/\r?\n/g,' '); }
function createReportPdf({report,projects,logs}) {
  const lines=[
    'JARVIS Executive Demo Report',
    `Period: ${report.start} to ${report.end}`,
    `Department: ${report.filters.department}`,
    `Revenue: $${report.revenue.toFixed(2)}`,
    `Expenses: $${report.expense.toFixed(2)}`,
    `Profit: $${report.profit.toFixed(2)}`,
    `Margin: ${report.margin===null?'Not available':report.margin.toFixed(2)+'%'}`,
    `Transactions: ${report.transactionCount}`,
    '',
    'Delayed Projects',
    ...projects.slice(0,10).map(p=>`${p.id} ${p.name}: ${p.progress}% complete, ${p.delayDays} days overdue`),
    '',
    'Recent Activity',
    ...logs.slice(0,8).map(log=>`${new Date(log.timestamp).toLocaleString()} - ${log.workflow} - ${log.status}`)
  ];
  const content=['BT','/F1 14 Tf','50 780 Td',...lines.flatMap((line,index)=>[(index? '0 -22 Td':'0 0 Td'),`(${pdfText(line)}) Tj`]),'ET'].join('\n');
  const objects=[
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
    `<< /Length ${Buffer.byteLength(content)} >>\nstream\n${content}\nendstream`
  ];
  let pdf='%PDF-1.4\n',offsets=[0];
  objects.forEach((object,index)=>{offsets.push(Buffer.byteLength(pdf));pdf+=`${index+1} 0 obj\n${object}\nendobj\n`;});
  const xref=Buffer.byteLength(pdf);
  pdf+=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n`;
  offsets.slice(1).forEach(offset=>{pdf+=String(offset).padStart(10,'0')+' 00000 n \n';});
  pdf+=`trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return Buffer.from(pdf);
}

function createServer({ db, externalToken = '', clock, gemini = {}, voice = {}, automation = {}, publicDemo = false } = {}) {
  const service = createService(db,{clock});
  const command = createCommandHandler(service,gemini), voiceHandler=createVoiceHandler(service);
  const voiceCalls=new Set();let lastVoiceStart=0;
  const server = http.createServer(async(req,res)=> {
    const send = (status,data) => { res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'}); res.end(JSON.stringify(data)); };
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('X-Frame-Options','DENY');
    res.setHeader('Cache-Control','no-store');
    res.setHeader('Referrer-Policy','no-referrer');
    let endpoint='';
    try {
      const host=req.headers.host || '', port=server.address().port;
      const url=new URL(req.url,`http://${host}`); endpoint=url.pathname;
      const voiceEndpoint=endpoint==='/api/retell/function' && req.method==='POST';
      const localHost = [`localhost:${port}`,`127.0.0.1:${port}`,`[::1]:${port}`].includes(host);
      const authorized=externalToken && sameSecret(req.headers.authorization || '',`Bearer ${externalToken}`);
      if (!localHost && !authorized && !voiceEndpoint && !publicDemo) throw new UserError('Host is not permitted.',403);
      if (!['GET','POST'].includes(req.method)) throw new UserError('Method not allowed.',405);
      if (req.headers.origin && req.headers.origin !== `http://${host}` && req.headers.origin !== `https://${host}` && !authorized) throw new UserError('Cross-origin requests are not permitted.',403);
      if (req.headers['sec-fetch-site']==='cross-site' && !authorized) throw new UserError('Cross-site requests are not permitted.',403);
      if (!localHost && !publicDemo && endpoint!=='/api/briefing' && !voiceEndpoint) throw new UserError('External access is limited to approved integration endpoints.',403);
      if (!endpoint.startsWith('/api/')) {
        if(req.method!=='GET') throw new UserError('Method not allowed.',405);
        const file=publicFiles.get(endpoint);
        if(!file) throw new UserError('Not found.',404);
        const contents=readFileSync(path.join(__dirname,'..',file[0]));
        res.writeHead(200,{'Content-Type':`${file[1]}; charset=utf-8`});res.end(contents);return;
      }
      let body={},rawBody='';
      if(req.method==='POST') {
        if(!(req.headers['content-type'] || '').startsWith('application/json')) throw new UserError('Use application/json.',415);
        const chunks=[];let length=0;
        for await (const chunk of req) { length+=chunk.length;if(length>(voiceEndpoint?262144:16384)) throw new UserError('Request too large.',413);chunks.push(chunk); }
        rawBody=Buffer.concat(chunks).toString('utf8');
        try {body=JSON.parse(rawBody);} catch {throw new UserError('Invalid JSON.');}
        if(!body || typeof body!=='object' || Array.isArray(body)) throw new UserError('Expected an object.');
      }
      const f=Object.fromEntries(url.searchParams);
      if(voiceEndpoint) {
        if(!voice.apiKey || !voice.agentId) throw new UserError('Voice integration is not configured.',503);
        if(!verifyVoiceSignature(rawBody,voice.apiKey,req.headers['x-retell-signature']))throw new UserError('Invalid voice signature.',401);
        if(body.call?.agent_id!==voice.agentId)throw new UserError('Unknown voice agent.',403);
        return send(200,voiceHandler(body));
      }
      if(req.method==='GET' && endpoint==='/api/health') return send(200,{ready:true,mode:'controlled-demo',geminiConfigured:Boolean(gemini.enabled && gemini.apiKey && gemini.model),voiceConfigured:Boolean(voice.apiKey && voice.agentId),voiceWebReady:Boolean(voice.enabled && voice.apiKey && voice.agentId),automationConfigured:Boolean(automation.n8nWebhookUrl)});
      if(req.method==='POST' && endpoint==='/api/automation/briefing') {
        if(!automation.n8nWebhookUrl)throw new UserError('n8n webhook is not configured.',503);
        const f=service.filters(body.filters || {});
        let upstream;
        try {
          upstream=await (automation.fetchImpl || fetch)(automation.n8nWebhookUrl,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source:'jarvis-dashboard',filters:f,requestedAt:new Date().toISOString()}),signal:AbortSignal.timeout(15000)});
        } catch {
          service.audit('n8n executive briefing','automation','webhook',f,{error:'n8n could not be reached'},'failed');
          throw new UserError('n8n webhook could not be reached.',502);
        }
        if(!upstream.ok) {
          service.audit('n8n executive briefing','automation','webhook',f,{status:upstream.status},'failed');
          throw new UserError('n8n webhook rejected the request.',502);
        }
        let result={accepted:true};
        try { result=await upstream.json(); } catch {}
        service.audit('n8n executive briefing','automation','webhook',f,{status:'sent'});
        return send(200,{mode:'controlled-demo',sent:true,result});
      }
      if(req.method==='POST' && (endpoint==='/api/voice/start' || endpoint.startsWith('/api/voice/stop/'))) {
        if(!voice.enabled || !voice.apiKey || !voice.agentId)throw new UserError('Web voice is not enabled. Complete voice setup first.',503);
        let upstreamPath, payload;
        if(endpoint==='/api/voice/start') {
          if(Date.now()-lastVoiceStart<30000)throw new UserError('Please wait 30 seconds before starting another call.',429);
          const f=service.filters(body.filters);
          lastVoiceStart=Date.now();upstreamPath='/v3/create-web-call';
          payload={agent_id:voice.agentId,metadata:{mode:'controlled-demo'},retell_llm_dynamic_variables:{demo_period:f.period,demo_department:f.department,demo_project:f.project,demo_status:f.status}};
        } else {
          const callId=endpoint.slice('/api/voice/stop/'.length);
          if(!voiceCalls.has(callId))throw new UserError('Unknown local voice call.',404);
          upstreamPath='/v2/stop-call/'+encodeURIComponent(callId);payload={};
        }
        let upstream;
        try {upstream=await (voice.fetchImpl || fetch)('https://api.retellai.com'+upstreamPath,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${voice.apiKey}`,'X-Retell-Client-JS-SDK-Version':'3.0.1'},body:JSON.stringify(payload),signal:AbortSignal.timeout(12000)});}
        catch {throw new UserError('Voice provider could not be reached. No active call has been confirmed.',502);}
        if(!upstream.ok)throw new UserError('Voice provider rejected the request. Check the private setup and account availability.',502);
        const result=await upstream.json();
        if(result.call_id)voiceCalls.add(result.call_id);
        for(const h of ['x-retell-client-js-sdk-min-version','x-retell-client-js-sdk-recommended-version']){const value=upstream.headers?.get(h);if(value)res.setHeader(h,value);}
        return send(200,result);
      }
      if(req.method==='GET' && endpoint==='/api/snapshot') return send(200,service.snapshot(f));
      if(req.method==='GET' && endpoint==='/api/report') return send(200,service.financial(f));
      if(req.method==='GET' && endpoint==='/api/projects') return send(200,service.projects(f));
      if(req.method==='GET' && endpoint==='/api/tasks') return send(200,service.tasks(f));
      if(req.method==='GET' && endpoint==='/api/audit') return send(200,service.logs());
      if(req.method==='GET' && endpoint==='/api/briefing') {
        if(!authorized) throw new UserError('Briefing requires a configured access token.',401);
        const report=service.financial(f),projects=service.projects({...f,status:'delayed'});
        service.audit('Executive briefing','report','briefing',report.filters,{revenue:report.revenue,delayedProjects:projects.length});
        return send(200,{mode:'controlled-demo',report,delayedProjects:projects});
      }
      if(req.method==='GET' && endpoint==='/api/export/report') {
        const report=service.financial(f),projects=service.projects({...f,status:'delayed'}),logs=service.logs();
        service.audit('Export executive report','report','pdf-export',report.filters,{revenue:report.revenue,delayedProjects:projects.length});
        const pdf=createReportPdf({report,projects,logs});
        res.writeHead(200,{'Content-Type':'application/pdf','Content-Disposition':'attachment; filename="jarvis-executive-report.pdf"','Content-Length':pdf.length});
        res.end(pdf);return;
      }
      if(req.method==='POST' && endpoint==='/api/command') return send(200,await command(body.prompt || body.query,body.filters));
      if(req.method==='POST' && endpoint==='/api/actions/propose') return send(200,service.propose(body));
      if(req.method==='POST' && endpoint==='/api/actions/execute') return send(200,service.execute(body));
      throw new UserError('Not found.',404);
    } catch(error) {
      const status=error instanceof UserError ? error.status : 500;
      // Never echo raw requests or credentials to the audit table or client.
      if(status===500) console.error('Request failed:',error.message);
      if(!res.headersSent) send(status,{error:status===500 ? 'Internal error. No success has been recorded.' : error.message});
      else res.end();
    }
  });
  server.requestTimeout=15000;server.headersTimeout=10000;
  return server;
}

if(require.main===module) {
  const envPath=path.join(__dirname,'../.env');
  if(existsSync(envPath))process.loadEnvFile(envPath);
  const db=openStore(process.env.JARVIS_DB);
  if(!db.prepare('SELECT COUNT(*) AS n FROM projects').get().n) seed(db);
  const port=Number(process.env.PORT || 3002);
  const server=createServer({db,externalToken:process.env.JARVIS_AUTOMATION_TOKEN || '',
    gemini:{apiKey:process.env.GEMINI_API_KEY || '',model:process.env.GEMINI_MODEL || '',enabled:process.env.GEMINI_ENABLED==='true'},
    voice:{apiKey:process.env.RETELL_API_KEY || '',agentId:process.env.RETELL_AGENT_ID || '',enabled:process.env.RETELL_WEB_CALL_ENABLED==='true'},
    automation:{n8nWebhookUrl:process.env.N8N_WEBHOOK_URL || ''},
    publicDemo:process.env.PUBLIC_DEMO_ENABLED !== 'false'});
  server.on('error',error=>{console.error(error.message);db.close();process.exitCode=1;});
  server.listen(port,'0.0.0.0',()=>console.log(`JARVIS controlled demo: http://0.0.0.0:${port}`));
  for(const signal of ['SIGINT','SIGTERM']) process.on(signal,()=>server.close(()=>{db.close();process.exit(0);}));
}
module.exports={createServer};


