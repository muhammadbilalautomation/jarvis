'use strict';
const {createHmac,timingSafeEqual}=require('node:crypto');
// Protocol reference: RetellAI/retell-typescript-sdk src/lib/webhook_auth.ts.
// Signatures cover the exact UTF-8 body followed by the millisecond timestamp.
function verifyVoiceSignature(raw,key,header,now=Date.now()) {
  if(!key || typeof header!=='string')return false;
  const parts=header.split(',');
  if(parts.length!==2 || !/^v=\d+$/.test(parts[0]) || !/^d=[0-9a-f]{64}$/i.test(parts[1]))return false;
  const timestamp=Number(parts[0].slice(2));
  if(!Number.isSafeInteger(timestamp) || Math.abs(now-timestamp)>300000)return false;
  const expected=createHmac('sha256',key).update(raw+timestamp).digest();
  return timingSafeEqual(expected,Buffer.from(parts[1].slice(2),'hex'));
}
module.exports={verifyVoiceSignature};
