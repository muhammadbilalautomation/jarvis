'use strict';

const { openStore } = require('./store');

const departments = [
  ['finance', 'Finance & Treasury'], ['operations', 'Operations & Supply'],
  ['projects', 'Projects & Strategy'], ['sales', 'Customer & Growth'], ['hr', 'HR & Governance']
];
const names = ['Global Cloud Migration','Automated Supply Chain Hub','FinTech Banking Gateway','Enterprise CRM AI Modernization',
  'Workforce Intelligence','Regional ERP Rollout','Treasury Dashboard','Security Modernization','Customer Portal','Service Quality'];

function seed(db, { count = 5000, seed = 42 } = {}) {
  if (!Number.isInteger(count) || count < 20 || count > 100000) throw new Error('Record count must be between 20 and 100000.');
  if (!Number.isInteger(seed) || seed < 1 || seed > 2147483646) throw new Error('Invalid seed.');
  if (db.prepare('SELECT COUNT(*) AS n FROM projects').get().n) throw new Error('Existing data preserved. Use a new database path to generate another dataset.');
  let state = seed;
  const random = n => { state = state * 16807 % 2147483647; return state % n; };
  db.exec('BEGIN IMMEDIATE');
  try {
    const dept = db.prepare('INSERT INTO departments VALUES(?,?)');
    departments.forEach(row => dept.run(...row));
    const emp = db.prepare('INSERT INTO employees VALUES(?,?,?)');
    for (let i = 0; i < 100; i++) emp.run(`EMP-${i + 1}`, departments[i % 5][0], `Demo Colleague ${String(i + 1).padStart(3, '0')}`);
    const customer = db.prepare('INSERT INTO customers VALUES(?,?)');
    for (let i = 0; i < 200; i++) customer.run(`CUS-${i + 1}`, `Demo Customer ${i + 1}`);
    const project = db.prepare('INSERT INTO projects VALUES(?,?,?,?,?,?,?)');
    const milestone = db.prepare('INSERT INTO milestones VALUES(?,?,?,?,?)');
    for (let i = 0; i < 20; i++) {
      const id = `PRJ-${101 + i}`;
      project.run(id, departments[i % 5][0], names[i % 10] + (i >= 10 ? ' — Phase 2' : ''), `EMP-${i + 1}`,
        (500000 + random(1000000)) * 100, '2025-01-01', i % 3 === 0 ? '2026-06-10' : '2026-09-30');
      for (let m = 0; m < 4; m++) {
        const due = `2026-${String(3 + m).padStart(2, '0')}-10`;
        milestone.run(`${id}-M${m + 1}`, id, ['Planning','Delivery','Review','Completion'][m], due,
          i % 5 === 0 || m < (i % 3 + 1) ? due : null);
      }
    }
    const transaction = db.prepare('INSERT INTO transactions VALUES(?,?,?,?,?,?,?)');
    for (let i = 0; i < count; i++) {
      const p = random(20), month = 1 + random(6), year = 2025 + random(2), kind = random(100) < 62 ? 'revenue' : 'expense';
      transaction.run(`TX-${i + 1}`, `PRJ-${101 + p}`, `EMP-${1 + p % 5 + 5 * random(20)}`,
        kind === 'revenue' ? `CUS-${1 + random(200)}` : null,
        `${year}-${String(month).padStart(2, '0')}-${String(1 + random(28)).padStart(2, '0')}`,
        kind, (1000 + random(49000)) * 100 + random(100));
    }
    const meta = db.prepare('INSERT INTO metadata VALUES(?,?)');
    meta.run('asOf', '2026-06-30');
    meta.run('seed', String(seed));
    meta.run('recordCount', String(count));
    meta.run('mode', 'controlled-demo');
    db.exec('COMMIT');
  } catch (error) { db.exec('ROLLBACK'); throw error; }
}

if (require.main === module) {
  const db = openStore(process.env.JARVIS_DB);
  try { seed(db, { count: Number(process.env.JARVIS_RECORDS || 5000), seed: Number(process.env.JARVIS_SEED || 42) }); console.log('Demo data created.'); }
  catch (error) { console.error(error.message); process.exitCode = 1; }
  finally { db.close(); }
}
module.exports = { seed };
