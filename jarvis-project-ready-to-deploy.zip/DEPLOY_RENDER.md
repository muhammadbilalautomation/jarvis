# JARVIS کو Render پر Live کرنے کا طریقہ

**آپ کے JARVIS project کو انٹرنیٹ پر رکھنے کے لیے یہ 5 آسان قدم ہیں:**

## Step 1: Zip فائل بنائیں

سب سے پہلے، اپنے کمپیوٹر پر:

```
jarvis-project/
  ├── package.json
  ├── render.yaml
  ├── index.html
  ├── app.js
  ├── data.js
  ├── charts.js
  ├── globe.js
  ├── styles.css
  └── backend/
      ├── server.js
      ├── service.js
      ├── store.js
      ├── seed.js
      ├── integrations.js
      ├── bitc-knowledge.js
      └── voice-signature.js
```

اس **پوری folder کو ZIP میں بنائیں۔**

---

## Step 2: Render.com پر جائیں

1. **render.com** کھولیں
2. اگر account نہیں ہے تو **Sign Up** کریں (GitHub یا Google سے)
3. اپنے account میں log in کریں

---

## Step 3: نیا Web Service بنائیں

1. Dashboard میں **"New +"** بٹن دبائیں
2. **"Web Service"** منتخب کریں
3. **"Public Repository"** کی بجائے **"Upload Files"** یا **"Paste Code"** منتخب کریں

اگر Upload option ہے:
- اپنی ZIP فائل upload کریں
- Render خود سے extract کر دے گا

---

## Step 4: Settings بھریں

ایک form آئے گا۔ یہ بھریں:

| Setting | Value |
|---------|-------|
| **Name** | jarvis-demo (یا اپنی پسند کا نام) |
| **Environment** | Node.js |
| **Build Command** | `npm install` |
| **Start Command** | `npm start` |
| **Environment Variables** | None (ابھی ضروری نہیں) |

---

## Step 5: Deploy کریں

**"Deploy"** بٹن دبائیں۔

Render:
- 2-3 منٹ میں build کرے گا
- خودکار server شروع کرے گا
- آپ کو ایک public link دے گا

---

## آپ کا Link

Deploy ہونے کے بعد، کچھ یوں URL ملے گا:

```
https://jarvis-demo-abc123.onrender.com
```

**یہی لنک کلائنٹ کو دے دیں!**

---

## اگر مسائل ہوں:

### "Build Failed" لکھا ہے؟
- اپنے ZIP میں check کریں کہ **package.json** موجود ہے
- تمام فائلیں صحیح جگہ ہیں

### Port error؟
- یہ فکر نہ کریں۔ Render خود PORT سیٹ کرے گا

### "Cannot find module" error؟
- Render.yaml check کریں
- Build Command صحیح ہے یا نہیں

---

## Local میں test کرنا (اختیاری)

اگر پہلے local میں test کرنا چاہیں:

```bash
cd jarvis-project
npm install
npm start
```

پھر http://localhost:3002 کھولیں

---

**تھوڑا سا انتظار کریں، اور پھر کلائنٹ کو لنک دے دیں! ✓**
