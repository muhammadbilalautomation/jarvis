'use strict';
let currentAppTheme='light', busy=false, pendingProposal=null;
let allProjects=[], health={};
const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:2}).format(n);
const pct=n=>n===null?'Not available':`${n>=0?'+':''}${n.toFixed(2)}%`;
const el=(tag,text,cls='')=>{const node=document.createElement(tag);node.textContent=text;node.className=cls;return node;};
const safeGlobe=state=>{try {setGlobeState(state);}catch{}};
function toggleTheme(){currentAppTheme=currentAppTheme==='light'?'dark':'light';document.body.classList.toggle('dark',currentAppTheme==='dark');document.documentElement.classList.toggle('dark',currentAppTheme==='dark');$('theme-toggle-text').textContent=currentAppTheme==='dark'?'Dark':'Light';try{updateGlobeTheme(currentAppTheme);}catch{}JarvisCharts.setTheme(currentAppTheme);}
function setBusy(value){busy=value;document.querySelectorAll('[data-busy], #command-form button[type="submit"], #filter-department, #filter-period, #filter-project, #filter-status').forEach(n=>n.disabled=value);$('connection-status').textContent=value?'Updating…':'Connected · demo data';}
function showError(error){$('connection-status').textContent='Request failed · retry available';$('page-error').textContent=error.message || String(error);$('page-error').classList.remove('hidden');if(pendingProposal)$('confirmation-error').textContent=error.message || String(error);appendChat('jarvis',error.message || String(error));safeGlobe('idle');}
function appendChat(role,text){
  const board=$('chat-board');
  if(!board || !text)return;
  const row=el('div','',`chat-message ${role==='user'?'user':'jarvis'}`);
  row.append(el('strong',role==='user'?'You':'JARVIS'),el('span',text));
  board.append(row);
  board.scrollTop=board.scrollHeight;
}
function showAnswer(text,{append=true}={}){if(append)appendChat('jarvis',text);safeGlobe('speaking');setTimeout(()=>safeGlobe('idle'),1800);}
function appendTranscript(role,text){
  if(!text || !$('voice-transcript'))return;
  $('voice-transcript').classList.remove('hidden');
  const row=el('div','',`voice-line ${role==='user'?'voice-user':'voice-jarvis'}`);
  row.append(el('strong',role==='user'?'You':'JARVIS'),el('span',text));
  $('voice-transcript').append(row);
  $('voice-transcript').scrollTop=$('voice-transcript').scrollHeight;
}
async function work(fn){if(busy)return;setBusy(true);$('page-error').classList.add('hidden');try{await fn();}catch(error){showError(error);}finally{setBusy(false);if(!$('page-error').classList.contains('hidden'))$('connection-status').textContent='Request failed · retry available';}}
function renderAgents(){const root=$('agents-grid');root.replaceChildren();JarvisData.agents.forEach(a=>{const button=el('button','', 'agent-card w-full text-left flex items-center gap-3 p-3 rounded-lg bg-slate-100/90 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 hover:border-sky-500');button.id=`agent-card-${a.id}`;button.append(el('span',String(a.id),'text-sky-600 font-bold font-mono'));const body=el('span','');body.append(el('span',a.name,'block text-xs font-bold'),el('span',a.detail,'block text-[10px] text-slate-500 mt-1'));button.append(body);button.onclick=()=>onAgentCardClicked(a.id);root.append(button);});}
function onAgentCardClicked(id){if(id===1)return $('command-input').focus();if(id===5)return $('filter-department').focus();if(id===6){$('tasks-section').scrollIntoView({behavior:'smooth'});return $('task-title').focus();}const a=JarvisData.agents.find(x=>x.id===id);processJarvisCommand(a.prompt);}
function renderSnapshot(){
  const s=JarvisData.snapshot;if(!s)return;const f=s.financial;
  const values={'kpi-arr':money(f.revenue),'kpi-sales':money(f.expense),'kpi-profit':money(f.profit),'kpi-working-cap':String(s.projects.length),'kpi-current-ratio':String(s.projects.filter(p=>p.status==='delayed').length),'kpi-conversion':f.margin===null?'Not available':f.margin.toFixed(2)+'%'};
  Object.entries(values).forEach(([id,text])=>$(id).textContent=text);
  $('revenue-change').textContent=f.yoy===null?'No prior-year comparison':pct(f.yoy)+' vs previous year';
  $('expense-note').textContent=f.transactionCount.toLocaleString()+' financial records';$('profit-note').textContent='Revenue minus recorded expenses';
  $('project-note').textContent=s.projects.filter(p=>p.status==='completed').length+' completed';$('risk-note').textContent='Derived from overdue milestones';$('margin-note').textContent='Profit ÷ revenue';
  $('selection-summary').textContent=`${f.start} — ${f.end} · ${s.departments.find(d=>d.id===s.filters.department)?.name || 'All departments'} · ${s.filters.status==='all'?'All project states':s.filters.status} · USD`;
  $('data-note').textContent=`Controlled demo · ${s.counts.transactions.toLocaleString()} generated financial records · Reference date ${s.asOf}`;
  ['department','period','project','status'].forEach(k=>$('filter-'+k).value=s.filters[k]);
  const matrix=$('operations-table-body');matrix.replaceChildren();
  f.departments.forEach(d=>{const row=el('tr','','border-b border-slate-200 dark:border-slate-800');[d.name,money(d.revenue),money(d.expense),money(d.profit),d.margin===null?'—':d.margin.toFixed(2)+'%',pct(d.yoy)].forEach((v,i)=>row.append(el('td',v,'py-2.5 px-3 '+(i?'text-right font-mono':''))));matrix.append(row);});
  const projects=$('projects-body');projects.replaceChildren();
  s.projects.forEach(p=>{const row=el('tr','','border-b border-slate-200 dark:border-slate-800');[`${p.id} · ${p.name}`,p.department,`${p.progress}%`,`${p.delayDays} days`,`${p.budgetUsed}%`,p.status].forEach(v=>row.append(el('td',v,'p-3 text-xs')));const cell=el('td','');const button=el('button','Create review','small-button');button.setAttribute('aria-label',`Create review for ${p.id}`);button.onclick=()=>proposeTask(p.id,`Review ${p.name}`);cell.append(button);row.append(cell);projects.append(row);});
  if(!s.projects.length){const row=el('tr','');const cell=el('td','No projects match this selection.','p-4 text-slate-500');cell.colSpan=7;row.append(cell);projects.append(row);}
  const tasks=$('tasks-list');tasks.replaceChildren();
  s.tasks.forEach(t=>{const row=el('div','','task-row');const body=el('div','');body.append(el('strong',t.title,'text-xs'),el('div',`${t.project_id} · ${t.status} · ${new Date(t.created_at).toLocaleString()}`,'text-[10px] text-slate-500 mt-1'));row.append(body);if(t.status==='open'){const button=el('button','Complete','small-button');button.setAttribute('aria-label',`Complete ${t.title}`);button.onclick=()=>work(async()=>displayProposal(await JarvisData.propose({type:'complete_task',taskId:t.id})));row.append(button);}else row.append(el('span','Completed','text-emerald-600 text-xs font-bold'));tasks.append(row);});
  if(!s.tasks.length)tasks.append(el('p','No saved tasks for this selection. Create a review task below.','text-xs text-slate-500 p-3'));
  renderAudit(s.audit);JarvisCharts.updateAll();if(!$('report-modal').classList.contains('hidden'))fillReport();
}
function renderAudit(logs){const root=$('audit-logs-container');root.replaceChildren();logs.forEach(log=>{const row=el('details','','audit-entry');const summary=el('summary',`${new Date(log.timestamp).toLocaleString()} · ${log.workflow} · ${log.status}`,'text-xs cursor-pointer font-mono');row.append(summary,el('p',log.request,'text-xs mt-1'));row.append(el('pre',JSON.stringify({action:log.action,parameters:log.parameters,result:log.result},null,2),'text-[10px] whitespace-pre-wrap mt-2'));root.append(row);});if(!logs.length)root.append(el('p','No activity yet. Ask a question to begin.','text-xs text-slate-500'));}
async function refresh(next){await JarvisData.load(next);renderSnapshot();}
function updateFilters(){const f={};['department','period','project','status'].forEach(k=>f[k]=$('filter-'+k).value);work(async()=>{try{await refresh(f);}catch(error){renderSnapshot();throw error;}});}
function resetFilters(){work(()=>refresh({department:'all',period:'Q2',project:'all',status:'all'}));}
async function processJarvisCommand(prompt){return work(async()=>{appendChat('user',prompt);$('command-input').value='';safeGlobe('listening');const result=await JarvisData.command(prompt);await refresh(result.filters || JarvisData.getFilter());showAnswer(result.answer+(result.notice?' '+result.notice:''));if(result.proposal)displayProposal(result.proposal);if(result.reportType==='projects')$('projects-section').scrollIntoView({behavior:'smooth',block:'start'});if(result.workflow==='audit')$('audit-logs-container').scrollIntoView({behavior:'smooth'});});}
function displayProposal(proposal){pendingProposal={...proposal,requestId:crypto.randomUUID()};$('confirmation-error').textContent='';$('confirmation-description').textContent=proposal.action.type==='create_task'?`Create a demo task: “${proposal.action.title}” for ${proposal.action.projectId}?`:'Mark this saved demo task as completed?';$('confirmation-modal').classList.remove('hidden');$('confirm-action').focus();}
function cancelProposal(){if(busy)return;pendingProposal=null;$('confirmation-modal').classList.add('hidden');}
function confirmProposal(){work(async()=>{if(!pendingProposal)return;const result=await JarvisData.execute(pendingProposal);pendingProposal=null;$('confirmation-modal').classList.add('hidden');showAnswer(`Demo task saved: ${result.task.title} — ${result.task.status}.`);await refresh({...JarvisData.getFilter(),department:'all',project:result.task.project_id,status:'all'});$('task-title').value='';$('tasks-section').scrollIntoView({behavior:'smooth'});});}
function proposeTask(projectId,title){work(async()=>displayProposal(await JarvisData.propose({type:'create_task',projectId,title})));}
function triggerQuickAction(type){if(type==='board_pack')return openReportModal();if(type==='risk_warning')return processJarvisCommand('Show delayed projects');if(type==='audit_sync')return work(()=>refresh());if(type==='n8n_briefing')return work(async()=>{await JarvisData.runBriefingAutomation();showAnswer('Executive briefing has been prepared for the selected filters.');await refresh();});}
function exportReportPdf(){const link=document.createElement('a');link.href=JarvisData.reportUrl();link.download='jarvis-executive-report.pdf';document.body.append(link);link.click();link.remove();showAnswer('Executive report file is being prepared for download.');}
function fillReport(){const s=JarvisData.snapshot;if(!s)return;const f=s.financial;$('modal-report-date').textContent=`${f.start} — ${f.end}`;$('modal-report-arr').textContent=money(f.revenue);$('modal-report-profit').textContent=money(f.profit);$('modal-report-state').textContent=s.projects.filter(p=>p.status==='delayed').length+' delayed projects';$('report-scope').textContent=$('selection-summary').textContent;$('report-financial').textContent=`Revenue ${money(f.revenue)} less expenses ${money(f.expense)} gives profit ${money(f.profit)}. ${f.transactionCount} selected records. Margin: ${f.margin===null?'not available':f.margin+'%'}.`;$('report-projects').textContent=`${s.projects.length} projects; ${s.projects.filter(p=>p.status==='completed').length} completed; ${s.projects.filter(p=>p.status==='delayed').length} delayed. Open saved tasks: ${s.tasks.filter(t=>t.status==='open').length}.`;$('modal-report-ratios').textContent=f.yoy===null?'No previous-year comparison available.':`Revenue change: ${pct(f.yoy)} against the same period last year.`;}
function openReportModal(){if(!JarvisData.snapshot || busy)return;fillReport();$('report-modal').classList.remove('hidden');}
function closeReportModal(){$('report-modal').classList.add('hidden');}
function openApiKeyModal(){$('api-key-modal').classList.remove('hidden');}
function closeApiKeyModal(){$('api-key-modal').classList.add('hidden');}
let retellClient=null, retellCall=null, voiceStarting=false;
function setMicState(active){
  $('voice-call-btn').classList.toggle('mic-listening',active);
  $('voice-call-btn').title=active?'JARVIS voice is live. Click to stop.':'Start JARVIS voice';
  $('mic-status').textContent=active?'Listening':'Talk to JARVIS';
  $('command-input').placeholder=active?'Speak with JARVIS…':'Ask JARVIS: Show Q2 financial performance…';
  safeGlobe(active?'listening':'idle');
}
async function toggleDashboardMic(){
  if(retellCall && retellCall.status!=='ended'){await retellCall.end();return;}
  if(voiceStarting)return;
  if(!health.voiceWebReady)return showError(new Error('JARVIS voice is not connected yet. Add the Retell agent id and private API key, then reload.'));
  voiceStarting=true;
  try{
    if(!retellClient){
      const {RetellClient}=await import('https://cdn.jsdelivr.net/npm/retell-client-js-sdk@3.0.1/+esm');
      retellClient=new RetellClient({key:'',fetch:(input)=>{
        const path=new URL(input.toString()).pathname;
        if(path==='/v3/create-web-call')return fetch('/api/voice/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filters:JarvisData.getFilter()})});
        if(/^\/v2\/stop-call\/[a-zA-Z0-9_-]+$/.test(path))return fetch('/api/voice/stop/'+path.split('/').pop(),{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
        throw new Error('Unsupported voice request.');
      }});
    }
    setMicState(true);
    retellCall=retellClient.createWebCall({agent_id:'server-managed-agent',hooks:{
      onStatus:status=>{setMicState(status==='live' || status==='connecting');if(status==='live')showAnswer('JARVIS voice is listening. Use your microphone for this conversation.');},
      onEnd:()=>{retellCall=null;setMicState(false);work(()=>refresh());},
      onError:error=>{retellCall=null;setMicState(false);showError(new Error('JARVIS voice call failed: '+(error?.message || 'unknown error')));}
    }});
  }catch(error){retellCall=null;setMicState(false);showError(error);}
  finally{voiceStarting=false;}
}
document.addEventListener('DOMContentLoaded',()=>{
  ['jarvis_gemini_key'].forEach(key=>{try{localStorage.removeItem(key);}catch{}});
  renderAgents();try{initJarvisGlobe('globe-container');}catch{$('globe-container').textContent='JARVIS';}
  if(!JarvisCharts.initAll())showError(new Error('Charts could not load. Check your connection and reload.'));
  if(window.lucide)lucide.createIcons();
  ['department','period','project','status'].forEach(k=>$('filter-'+k).addEventListener('change',updateFilters));
  $('command-form').addEventListener('submit',event=>{event.preventDefault();const prompt=$('command-input').value.trim();if(prompt)processJarvisCommand(prompt);});
  $('task-form').addEventListener('submit',event=>{event.preventDefault();proposeTask($('task-project').value,$('task-title').value);});
  $('voice-call-btn').onclick=toggleDashboardMic;
  $('confirm-action').onclick=confirmProposal;$('cancel-action').onclick=cancelProposal;
  document.addEventListener('keydown',event=>{if(event.key==='Escape'){cancelProposal();closeApiKeyModal();closeReportModal();}});
  work(async()=>{
    [allProjects,health]=await Promise.all([JarvisData.request('/api/projects?period=H1'),JarvisData.request('/api/health')]);
    for(const id of ['filter-project','task-project']){const select=$(id);if(id==='filter-project')select.append(new Option('All projects','all'));allProjects.forEach(p=>select.append(new Option(`${p.id} · ${p.name}`,p.id)));}
    $('gemini-badge').textContent='EXECUTIVE CORE';
    $('integration-status').textContent='JARVIS is ready for dashboard commands, spoken questions, reports, safe demo tasks and activity history.';
    $('voice-badge').textContent=health.voiceWebReady?'VOICE READY':'VOICE SETUP';
    await refresh();
  });
});


