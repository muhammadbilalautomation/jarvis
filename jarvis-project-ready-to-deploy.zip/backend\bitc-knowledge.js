'use strict';

const sectors = ['Agriculture','Automotive','Cargo, Freight & Logistics','Education','Financial & Business Services','Health','ICT','Manufacturing','Mining','Tourism'];
const facts = {
  overview: 'BITC is Botswana Investment and Trade Centre. It supports Botswana economic growth by attracting foreign and domestic investment, facilitating business expansion, promoting exports, and managing the Nation Brand.',
  invest: 'BITC helps local and foreign investors with investment opportunities, accreditation, certification, incentives, tax relief, training grants, and business facilitation.',
  export: 'BITC supports export-led growth through exporter readiness, advisory services, trade missions, buyer-seller meetings, standards support, trade and market information, trade leads, product adaptation, and Global Expo Botswana.',
  bossc: 'BOSSC is the Botswana One Stop Service Centre inside BITC. It helps investors with business registration, licenses, visas, work and residence permits, utilities, tax and VAT registration, land access, factory space where available, EIA compliance, advisory services, and business climate information.',
  incentives: 'Investment benefits mentioned by BITC include double taxation avoidance agreements, no foreign exchange controls, free repatriation of profits and capital, duty rebates on machinery and raw materials, general company tax at 22%, withholding tax on dividends at 7.5%, possible tax holidays, and training rebates. IFSC-approved companies may access incentives such as 15% corporate tax and selected withholding tax exemptions.',
  contact: 'BITC website lists fraud and ethics hotline 16138 for Orange, Mascom, BTC and BeMobile, and email bitc@tip-offs.com. Main website: www.bitc.co.bw.'
};

function answerBitcQuestion(question) {
  const q = String(question || '').toLowerCase();
  if(!/\b(bitc|botswana|invest|investment|export|exporter|bossc|one stop|sector|incentive|tax|fraud|hotline|trade)\b/i.test(q)) return null;
  if(/\bsector|industry|industries|opportunit/.test(q)) return `BITC highlights these investment sectors: ${sectors.join(', ')}.`;
  if(/\bbossc|one stop|license|permit|visa|land|utilities|registration/.test(q)) return facts.bossc;
  if(/\bexport|exporter|trade|expo|market|lead/.test(q)) return facts.export;
  if(/\bincentive|tax|ifsc|rebate|foreign exchange|dividend|holiday/.test(q)) return facts.incentives;
  if(/\bcontact|fraud|hotline|email|phone/.test(q)) return facts.contact;
  if(/\binvest|investor|accredit|business/.test(q)) return facts.invest;
  return `${facts.overview} ${facts.invest}`;
}

module.exports = { answerBitcQuestion, facts, sectors };
