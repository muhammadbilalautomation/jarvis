'use strict';
const JarvisCharts = (() => {
  const charts = new Map(); let theme = 'light';
  const ids = ['waterfall','radar','trend','funnel','gauge','employees'];
  const color = () => ({ text: theme === 'dark' ? '#94a3b8' : '#64748b', grid: theme === 'dark' ? '#1e293b' : '#e2e8f0', accent: theme === 'dark' ? '#00d2ff' : '#0284c7' });
  function initAll() { if (typeof echarts === 'undefined') return false; ids.forEach(id => charts.set(id, echarts.init(document.getElementById('chart-' + id)))); window.addEventListener('resize', resizeAll); return true; }
  function resizeAll() { charts.forEach(chart => chart.resize()); }
  function setTheme(value) { theme = value; updateAll(); }
  function updateAll() {
    const s = JarvisData.snapshot; if (!s || !charts.size) return;
    const f = s.financial, c = color();
    const base = { backgroundColor: 'transparent', textStyle: { color: c.text, fontFamily: 'sans-serif' }, tooltip: { trigger: 'axis', confine: true },
      grid: { left: 8, right: 12, top: 24, bottom: 4, containLabel: true },
      xAxis: { type: 'category', axisLabel: { color: c.text, fontSize: 10 }, axisLine: { lineStyle: { color: c.grid } } },
      yAxis: { type: 'value', axisLabel: { color: c.text, fontSize: 10, formatter: v => '$' + (v / 1000000).toFixed(1) + 'm' }, splitLine: { lineStyle: { color: c.grid } } } };
    const set = (id, option, empty = false) => charts.get(id).setOption(empty ? { title: { text: 'No matching data', left: 'center', top: 'center', textStyle: { color: c.text, fontSize: 12, fontWeight: 'normal' } } } : option, true);
    set('waterfall', { ...base, xAxis: { ...base.xAxis, data: ['Revenue','Expenses','Profit'] }, series: [
      { type: 'bar', stack: 'total', silent: true, itemStyle: { color: 'transparent' }, data: [0, Math.max(0,f.profit),0] },
      { name: 'USD', type: 'bar', stack: 'total', itemStyle: { borderRadius: [4,4,0,0] }, data: [
        { value:f.revenue,itemStyle:{color:c.accent} },{value:f.expense,itemStyle:{color:'#f43f5e'}},{value:f.profit,itemStyle:{color:f.profit>=0?'#10b981':'#f43f5e'}}] } ] }, !f.transactionCount);
    const radar = f.departments.length >= 3 ? f.departments : s.departments.map(d => f.departments.find(x => x.id === d.id) || { name: d.name, revenue:0, expense:0 });
    const ceiling = Math.max(1,...radar.flatMap(d=>[d.revenue,d.expense]))*1.1;
    set('radar', { tooltip:{trigger:'item',confine:true}, legend:{bottom:0,textStyle:{color:c.text},data:['Revenue','Expenses']},
      radar:{ radius:'58%',center:['50%','44%'],indicator:radar.map(d=>({name:d.name.split(' & ')[0],max:ceiling})),axisName:{color:c.text,fontSize:10},splitArea:{show:false},splitLine:{lineStyle:{color:c.grid}},axisLine:{lineStyle:{color:c.grid}} },
      series:[{type:'radar',data:[{name:'Revenue',value:radar.map(d=>d.revenue),itemStyle:{color:c.accent},areaStyle:{opacity:.15}},
        {name:'Expenses',value:radar.map(d=>d.expense),itemStyle:{color:'#f59e0b'},areaStyle:{opacity:.08}}]}] }, !f.transactionCount);
    set('trend', { ...base, legend:{top:0,textStyle:{color:c.text,fontSize:10}},grid:{...base.grid,top:30},xAxis:{...base.xAxis,data:f.monthly.map(m=>new Date(m.month+'-01T00:00:00Z').toLocaleString('en',{month:'short',timeZone:'UTC'}))},
      series:[{name:'Selected period',type:'line',data:f.monthly.map(m=>m.revenue),smooth:true,lineStyle:{color:c.accent},itemStyle:{color:c.accent},areaStyle:{opacity:.12}},
        {name:'Previous year',type:'line',data:f.monthly.map(m=>m.previousRevenue),lineStyle:{type:'dashed',color:'#94a3b8'},itemStyle:{color:'#94a3b8'}}] }, !f.transactionCount);
    const cutoff = f.end < s.asOf ? f.end : s.asOf;
    const stages = ['Planning','Delivery','Review','Completion'].map((name,index) => ({name,value:s.projects.filter(p=>p.milestones.slice(0,index+1).every(m=>m.completed_date && m.completed_date<=cutoff)).length}));
    set('funnel', {tooltip:{trigger:'item',confine:true},series:[{type:'funnel',left:'8%',right:'8%',top:4,bottom:4,sort:'none',max:Math.max(1,s.projects.length),gap:3,
      label:{position:'inside',color:'#fff',fontSize:10,formatter:'{b}: {c}'},data:stages.map((d,i)=>({...d,itemStyle:{color:['#6366f1','#0284c7','#0ea5e9','#10b981'][i]}}))}]}, !s.projects.length);
    const margin=f.margin;
    set('gauge', {series:[{type:'gauge',startAngle:180,endAngle:0,min:Math.min(0,Math.floor(margin ?? 0)),max:100,radius:'95%',center:['50%','78%'],
      progress:{show:true,width:12,roundCap:true},pointer:{show:false},axisLine:{lineStyle:{width:12,color:[[1,c.grid]]}},axisTick:{show:false},splitLine:{show:false},axisLabel:{show:false},
      itemStyle:{color:margin<0?'#f43f5e':c.accent},title:{offsetCenter:[0,'15%'],fontSize:10,color:c.text},detail:{offsetCenter:[0,'-30%'],fontSize:22,color:c.accent,formatter:'{value}%'},
      data:[{value:margin,name:'Calculated margin'}]}]},margin===null);
    set('employees',{...base,xAxis:{...base.xAxis,data:f.employees.map(e=>e.name.replace('Demo Colleague ','#'))},series:[{name:'Revenue',type:'bar',data:f.employees.map(e=>e.revenue),itemStyle:{color:c.accent,borderRadius:[4,4,0,0]}}]},!f.employees.length);
  }
  return {initAll,updateAll,setTheme,resizeAll};
})();
