'use strict';
const JarvisData = (() => {
  let snapshot = null;
  let filter = { department: 'all', period: 'Q2', project: 'all', status: 'all' };
  const agents = [
    { id: 1, name: 'JARVIS Command', detail: 'Ask an executive question', prompt: '' },
    { id: 2, name: 'Request Router', detail: 'Select the right approved workflow', prompt: 'Show financial performance for Q2' },
    { id: 3, name: 'Demo Data', detail: 'Connected, reproducible records', prompt: 'Show data overview' },
    { id: 4, name: 'Report Generator', detail: 'Calculated financial and project reports', prompt: 'Show financial performance' },
    { id: 5, name: 'Dashboard & Filters', detail: 'One selection across all results', prompt: '' },
    { id: 6, name: 'Action Executor', detail: 'Create and complete demo tasks', prompt: '' },
    { id: 7, name: 'Audit History', detail: 'Saved requests, actions and outcomes', prompt: 'Show audit history' }
  ];
  async function request(url, body) {
    const response = await fetch(url, { method: body === undefined ? 'GET' : 'POST',
      headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(20000) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'The request could not be completed.');
    return result;
  }
  return { agents, request, get snapshot() { return snapshot; }, getFilter: () => ({ ...filter }),
    async load(next = filter) { const result = await request('/api/snapshot?' + new URLSearchParams(next)); snapshot = result; filter = { ...result.filters }; return result; },
    command: prompt => request('/api/command', { prompt, filters: filter }),
    propose: action => request('/api/actions/propose', action),
    execute: proposal => request('/api/actions/execute', { token: proposal.token, requestId: proposal.requestId, confirmed: true }),
    runBriefingAutomation: () => request('/api/automation/briefing', { filters: filter }),
    reportUrl: () => '/api/export/report?' + new URLSearchParams(filter) };
})();
