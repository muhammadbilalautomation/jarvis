'use strict';

const { randomUUID, createHash } = require('node:crypto');
const { answerBitcQuestion } = require('./bitc-knowledge');

class UserError extends Error {
  constructor(message, status = 400) { super(message); this.status = status; }
}
const money = cents => cents / 100;
const percent = (a, b) => b ? Math.round(a / b * 10000) / 100 : null;
const windows = {
  Q1: ['2026-01-01', '2026-03-31'], Q2: ['2026-04-01', '2026-06-30'],
  FY25: ['2025-01-01', '2025-12-31'], H1: ['2026-01-01', '2026-06-30']
};

function createService(db, { clock = () => new Date() } = {}) {
  const now = () => clock().toISOString();
  const asOf = db.prepare("SELECT value FROM metadata WHERE key='asOf'").get()?.value;
  function filters(input = {}) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new UserError('Invalid filters.');
    const f = { period: input.period || 'Q2', department: input.department || 'all', project: input.project || 'all', status: input.status || 'all' };
    if (Object.values(f).some(value => typeof value !== 'string')) throw new UserError('Filter values must be text.');
    if (!Object.hasOwn(windows, f.period)) throw new UserError('Choose Q1, Q2, H1 or FY25.');
    if (f.department !== 'all' && !db.prepare('SELECT id FROM departments WHERE id=?').get(f.department)) throw new UserError('Unknown department.');
    if (f.project !== 'all' && !db.prepare('SELECT id FROM projects WHERE id=?').get(f.project)) throw new UserError('Unknown project.');
    if (!['all', 'delayed', 'completed', 'on-track'].includes(f.status)) throw new UserError('Unknown project status.');
    return f;
  }
  function projects(input = {}) {
    const f = filters(input), cutoff = windows[f.period][1] < asOf ? windows[f.period][1] : asOf;
    return db.prepare(`SELECT p.*,e.name AS lead,d.name AS department FROM projects p
      JOIN employees e ON e.id=p.lead_id JOIN departments d ON d.id=p.department_id
      WHERE (?='all' OR p.department_id=?) AND (?='all' OR p.id=?) AND p.start_date<=? ORDER BY p.id`)
      .all(f.department, f.department, f.project, f.project, cutoff).map(p => {
        const milestones = db.prepare('SELECT * FROM milestones WHERE project_id=? ORDER BY id').all(p.id);
        const completed = milestones.filter(m => m.completed_date && m.completed_date <= cutoff).length;
        const overdue = milestones.filter(m => m.due_date < cutoff && (!m.completed_date || m.completed_date > cutoff));
        const status = completed === milestones.length ? 'completed' : overdue.length || p.due_date < cutoff ? 'delayed' : 'on-track';
        const spent = db.prepare("SELECT COALESCE(SUM(amount_cents),0) AS n FROM transactions WHERE project_id=? AND kind='expense' AND date<=?").get(p.id, cutoff).n;
        const firstLate = overdue.map(m => m.due_date).concat(p.due_date < cutoff && status !== 'completed' ? [p.due_date] : []).sort()[0];
        return { id: p.id, name: p.name, departmentId: p.department_id, department: p.department, lead: p.lead,
          budget: money(p.budget_cents), spent: money(spent), budgetUsed: percent(spent, p.budget_cents),
          progress: percent(completed, milestones.length), status, dueDate: p.due_date,
          delayDays: firstLate ? Math.floor((Date.parse(cutoff) - Date.parse(firstLate)) / 86400000) : 0, milestones };
      }).filter(p => f.status === 'all' || p.status === f.status);
  }
  function financial(input = {}) {
    const f = filters(input), [start, end] = windows[f.period], ids = new Set(projects(f).map(p => p.id));
    const read = (from, to) => db.prepare('SELECT * FROM transactions WHERE date BETWEEN ? AND ? ORDER BY date,id').all(from, to).filter(t => ids.has(t.project_id));
    const rows = read(start, end), previous = read(start.replace(/^\d{4}/, x => String(Number(x) - 1)), end.replace(/^\d{4}/, x => String(Number(x) - 1)));
    function sum(items, kind) { return items.filter(t => t.kind === kind).reduce((n, t) => n + t.amount_cents, 0); }
    const rev = sum(rows, 'revenue'), cost = sum(rows, 'expense'), prev = sum(previous, 'revenue');
    const monthly = [];
    for (let m = Number(start.slice(5, 7)); m <= Number(end.slice(5, 7)); m++) {
      const month = String(m).padStart(2, '0'), subset = rows.filter(t => t.date.slice(5, 7) === month);
      monthly.push({ month: `${start.slice(0, 4)}-${month}`, revenue: money(sum(subset, 'revenue')),
        expense: money(sum(subset, 'expense')), previousRevenue: money(sum(previous.filter(t => t.date.slice(5, 7) === month), 'revenue')) });
    }
    const projectDepartments = new Map(db.prepare('SELECT id,department_id FROM projects').all().map(p => [p.id, p.department_id]));
    const departments = db.prepare('SELECT * FROM departments ORDER BY id').all().filter(d => f.department === 'all' || f.department === d.id).map(d => {
      const tx = rows.filter(t => projectDepartments.get(t.project_id) === d.id), revenue = sum(tx, 'revenue'), expense = sum(tx, 'expense');
      const last = sum(previous.filter(t => projectDepartments.get(t.project_id) === d.id), 'revenue');
      return { id: d.id, name: d.name, revenue: money(revenue), expense: money(expense), profit: money(revenue - expense), margin: percent(revenue - expense, revenue), yoy: last ? percent(revenue - last, last) : null };
    });
    const employees = db.prepare('SELECT id,name FROM employees').all().map(e => ({ ...e, revenue: money(sum(rows.filter(t => t.employee_id === e.id), 'revenue')) })).filter(e => e.revenue > 0).sort((a,b) => b.revenue-a.revenue).slice(0,8);
    return { filters: f, start, end, revenue: money(rev), expense: money(cost), profit: money(rev-cost), margin: percent(rev-cost,rev),
      previousRevenue: money(prev), yoy: prev ? percent(rev-prev,prev) : null, transactionCount: rows.length,
      customerCount: new Set(rows.filter(t => t.customer_id).map(t => t.customer_id)).size,
      monthly, departments, employees, revenueCents: rev, expenseCents: cost };
  }
  function audit(request, workflow, action, parameters, result, status = 'success') {
    const id = randomUUID();
    db.prepare('INSERT INTO audit VALUES(?,?,?,?,?,?,?,?)').run(id, request, workflow, action, JSON.stringify(parameters), JSON.stringify(result), status, now());
    return id;
  }
  function logs() {
    return db.prepare('SELECT * FROM audit ORDER BY rowid DESC LIMIT 100').all().map(row => ({ ...row, parameters: JSON.parse(row.parameters), result: JSON.parse(row.result) }));
  }
  function tasks(input = {}) {
    const ids = new Set(projects(input).map(p => p.id));
    return db.prepare('SELECT * FROM tasks ORDER BY created_at DESC,id').all().filter(t => ids.has(t.project_id));
  }
  function snapshot(input = {}) {
    const f = filters(input);
    return { mode: 'controlled-demo', asOf, filters: f, financial: financial(f), projects: projects(f), tasks: tasks(f), audit: logs(),
      departments: db.prepare('SELECT * FROM departments').all(),
      counts: { projects: db.prepare('SELECT COUNT(*) AS n FROM projects').get().n, transactions: db.prepare('SELECT COUNT(*) AS n FROM transactions').get().n } };
  }
  function actionDetails(input) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new UserError('Invalid action.');
    if (input.type === 'create_task') {
      if (typeof input.projectId !== 'string' || !db.prepare('SELECT id FROM projects WHERE id=?').get(input.projectId)) throw new UserError('Choose an existing project.');
      if (typeof input.title !== 'string' || !input.title.trim() || input.title.trim().length > 200) throw new UserError('Task title must contain 1 to 200 characters.');
      return { type: input.type, projectId: input.projectId, title: input.title.trim() };
    }
    if (input.type === 'complete_task') {
      if (typeof input.taskId !== 'string' || !db.prepare('SELECT id FROM tasks WHERE id=?').get(input.taskId)) throw new UserError('Choose an existing task.');
      return { type: input.type, taskId: input.taskId };
    }
    throw new UserError('Only creating and completing demo tasks is supported.');
  }
  function propose(input, request = 'Demo action') {
    const action = actionDetails(input), token = randomUUID(), expiresAt = new Date(clock().getTime() + 10 * 60000).toISOString();
    db.prepare('INSERT INTO confirmations VALUES(?,?,?,0)').run(token, JSON.stringify(action), expiresAt);
    audit(request, 'action', 'propose', action, { confirmationRequired: true });
    return { confirmationRequired: true, token, expiresAt, action };
  }
  function execute(input) {
    if (!input || input.confirmed !== true) throw new UserError('Explicit confirmation is required.');
    if (typeof input.token !== 'string' || typeof input.requestId !== 'string' || !/^[a-zA-Z0-9_-]{8,100}$/.test(input.requestId)) throw new UserError('A confirmation token and request identifier are required.');
    const fingerprint = createHash('sha256').update(input.token).digest('hex');
    db.exec('BEGIN IMMEDIATE');
    try {
      const saved = db.prepare('SELECT * FROM requests WHERE key=?').get(input.requestId);
      if (saved) {
        if (saved.fingerprint !== fingerprint) throw new UserError('Request identifier already belongs to another action.',409);
        db.exec('COMMIT'); return JSON.parse(saved.response);
      }
      const proposal = db.prepare('SELECT * FROM confirmations WHERE token=?').get(input.token);
      if (!proposal || proposal.used || proposal.expires_at <= now()) throw new UserError('Confirmation expired or already used.',409);
      const action = actionDetails(JSON.parse(proposal.action));
      let task;
      if (action.type === 'create_task') {
        const id = `TSK-${randomUUID()}`;
        db.prepare("INSERT INTO tasks VALUES(?,?,?,'open',?,NULL)").run(id,action.projectId,action.title,now());
        task = db.prepare('SELECT * FROM tasks WHERE id=?').get(id);
      } else {
        db.prepare("UPDATE tasks SET status='completed',completed_at=? WHERE id=? AND status='open'").run(now(),action.taskId);
        task = db.prepare('SELECT * FROM tasks WHERE id=?').get(action.taskId);
      }
      db.prepare('UPDATE confirmations SET used=1 WHERE token=?').run(input.token);
      const result = { success: true, mode: 'controlled-demo', task: { ...task } };
      result.auditId = audit('Confirmed demo action','action',action.type,action,{ taskId: task.id, status: task.status });
      db.prepare('INSERT INTO requests VALUES(?,?,?)').run(input.requestId,fingerprint,JSON.stringify(result));
      db.exec('COMMIT'); return result;
    } catch (error) {
      db.exec('ROLLBACK');
      audit('Demo action failed','action','execute',{}, { error: error.message },'failed');
      throw error;
    }
  }
  function command(prompt, input = {}) {
    if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > 2000) throw new UserError('Enter a question of 1 to 2000 characters.');
    const q = prompt.trim(), lower = q.toLowerCase(), f = filters(input);
    if (/^(hi|hy|hello|hey|salam|assalam|السلام|ہیلو|ہی|ہائے|سلام)$/iu.test(q)) {
      const answer = 'Hello. I am JARVIS. You can ask about BITC information, Q2 financial performance, delayed projects, audit history, or safe demo review tasks.';
      audit(q,'chat','greeting',{}, {status:'ready'});
      return {workflow:'chat',answer,filters:f};
    }
    const bitcAnswer = answerBitcQuestion(q);
    if (bitcAnswer) {
      audit(q,'knowledge','bitc-answer',{}, {source:'bitc.co.bw'});
      return {workflow:'knowledge',answer:bitcAnswer,filters:f,source:'BITC public website'};
    }
    if (/\b(data overview|demo data)\b|فرضی معلومات/iu.test(q)) {
      const counts = { transactions: db.prepare('SELECT COUNT(*) n FROM transactions').get().n, projects: db.prepare('SELECT COUNT(*) n FROM projects').get().n };
      audit(q,'data','overview',{},counts);
      return {workflow:'data',answer:`Controlled demo: ${counts.transactions} generated financial records and ${counts.projects} projects. Reference date ${asOf}. No real enterprise connections.`,filters:f};
    }
    const quarter = lower.match(/\bq([1-4])\b/);
    if(quarter && !['1','2'].includes(quarter[1]))return {...clarify(q,'The demo contains Q1 and Q2 2026, plus FY 2025. Please choose one of these periods.'),unsupported:true};
    const explicitYear=lower.match(/\b(20\d{2})\b/);
    if(explicitYear && !['2025','2026'].includes(explicitYear[1]))return {...clarify(q,'No demo records exist for that year. Available years are 2025 and the first half of 2026.'),unsupported:true};
    if (quarter) f.period = `Q${quarter[1]}`;
    if(/last quarter|previous quarter|پچھلی سہ ماہی/iu.test(q))f.period='Q1';
    if(/\bfy\s?2025\b|\bfy25\b/iu.test(q))f.period='FY25';
    if(/\bh1\b|first half/iu.test(q))f.period='H1';
    if(explicitYear?.[1]==='2025' && quarter)return {...clarify(q,'For 2025, select the available full-year report. Quarterly reports are available for 2026.'),unsupported:true};
    const mentionedDepartments = ['finance','operations','projects','sales','hr'].filter(d => new RegExp(`\\b${d}\\s+(department|team)\\b|\\bdepartment\\s+${d}\\b`).test(lower));
    if (mentionedDepartments.length > 1) return clarify(q,'Please choose one department.');
    if (mentionedDepartments.length) f.department = mentionedDepartments[0];
    const p = q.match(/\bPRJ-\d+\b/i);
    if (p) {
      f.project = p[0].toUpperCase();
      const department=db.prepare('SELECT department_id FROM projects WHERE id=?').get(f.project)?.department_id;
      if(mentionedDepartments.length && department && f.department!==department)return clarify(q,'That project belongs to a different department. Please choose a matching project or department.');
      if(!mentionedDepartments.length)f.department='all';
    }
    filters(f);
    if (/\b(create|add|assign)\b.*\b(task|review)\b|کام.*(درج|بناؤ|بنا)/iu.test(q)) {
      if (f.project === 'all') return clarify(q,'Choose a project before creating its review task.');
      return { workflow: 'action', answer: `Confirm creation of a review task for ${f.project}.`, filters:f,
        proposal: propose({type:'create_task', projectId:f.project,title:`Review ${f.project}`},q) };
    }
    if (/\b(complete|finish|delete|send|pay|transfer|update|schedule)\b|مکمل|حذف|بھیج|ادائیگی/iu.test(q)) return {...clarify(q,'Use the task controls to complete a task. Sending messages, payments and other actions are not enabled.'),unsupported:true};
    if (/\b(project|projects|delay|delayed|risk|milestone)\b|منصوب|تاخیر/iu.test(q)) {
      if (/delay|risk|تاخیر/iu.test(q)) f.status='delayed';
      const list = projects(f), answer = `${list.length} ${f.status === 'delayed' ? 'delayed ' : ''}projects in the selected period. ${list.slice(0,3).map(p => `${p.id}: ${p.progress}% complete, ${p.delayDays} days overdue`).join('; ')}`;
      audit(q,'report','projects',f,{count:list.length});
      return {workflow:'report',reportType:'projects',answer,filters:f,projects:list};
    }
    if (/\b(revenue|expense|profit|financial|finance|sales|performance|q1|q2|report|summary)\b|آمدن|خرچ|منافع|مالی|خلاصہ/iu.test(q)) {
      const report = financial(f), fmt=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:2}).format(n);
      const answer=`${f.period}: revenue ${fmt(report.revenue)}, expenses ${fmt(report.expense)}, profit ${fmt(report.profit)}. Based on ${report.transactionCount} demo records.`;
      audit(q,'report','financial',f,{revenue:report.revenue,expense:report.expense,profit:report.profit});
      return {workflow:'report',reportType:'financial',answer,filters:f,report};
    }
    if (/\b(audit|history|logs)\b|تاریخ/iu.test(q)) {
      audit(q,'audit','read',f,{status:'read'});
      return {workflow:'audit',answer:'Saved demo activity is shown below.',filters:f,audit:logs()};
    }
    return clarify(q,'I can help with BITC information, Q2 financial performance, delayed projects, audit history, or a safe demo review task for a project such as PRJ-104.');
  }
  function clarify(request,answer) { audit(request,'router','clarify',{}, {answer},'needs-input'); return {workflow:'router',answer,needsInput:true}; }
  function bindVoiceProposal(token,callId) { db.prepare('INSERT INTO voice_confirmations VALUES(?,?)').run(token,callId); }
  function checkVoiceProposal(token,callId) {
    if(typeof token!=='string' || typeof callId!=='string' || !db.prepare('SELECT token FROM voice_confirmations WHERE token=? AND call_id=?').get(token,callId)) throw new UserError('Voice confirmation does not belong to this conversation.',403);
  }
  return { filters, projects, financial, tasks, logs, snapshot, propose, execute, command, audit, bindVoiceProposal, checkVoiceProposal };
}
module.exports = { createService, UserError };

