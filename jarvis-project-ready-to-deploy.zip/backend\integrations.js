'use strict';
const { UserError }=require('./service');
const intentSchema={type:'object',properties:{
  intent:{type:'string',enum:['financial','projects','audit','create_task','unsupported']},
  department:{type:'string',enum:['all','finance','operations','projects','sales','hr']},
  period:{type:'string',enum:['Q1','Q2','H1','FY25']},
  project:{type:'string'},status:{type:'string',enum:['all','delayed','completed','on-track']},title:{type:'string'}
},required:['intent','department','period','project','status','title'],additionalProperties:false};
function createCommandHandler(service,{apiKey='',model='',enabled=false,fetchImpl=fetch}={}) {
  return async function handle(prompt,filters={}) {
    const local=service.command(prompt,filters);
    if(!local.needsInput || local.unsupported || !enabled || !apiKey || !model)return local;
    try {
      if(!/^[a-zA-Z0-9._-]+$/.test(model))throw new Error('Invalid model name.');
      const response=await fetchImpl(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{
        method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':apiKey},signal:AbortSignal.timeout(12000),
        body:JSON.stringify({systemInstruction:{parts:[{text:'Classify an executive DEMO request. Never calculate or invent financial data. Only supported intents in schema. No sending, payment, deletion, real-world actions, or executing tasks. create_task only proposes a local review task. Unsupported or ambiguous requests use unsupported. Extract only explicitly supplied scope, otherwise preserve supplied filters. Project must be all or PRJ-101 through PRJ-120. Return schema only.'}]},
          contents:[{role:'user',parts:[{text:JSON.stringify({request:prompt,filters:service.filters(filters)})}]}],
          generationConfig:{temperature:0,responseMimeType:'application/json',responseJsonSchema:intentSchema}})
      });
      if(!response.ok)throw new Error('Text service unavailable.');
      const body=await response.json();const text=body.candidates?.[0]?.content?.parts?.filter(p=>p.text).map(p=>p.text).join('');
      const intent=JSON.parse(text);
      if(!intent || !['financial','projects','audit','create_task','unsupported'].includes(intent.intent))throw new Error('Invalid intent.');
      const f=service.filters({department:intent.department,period:intent.period,project:intent.project,status:intent.status});
      if(intent.intent==='unsupported')return local;
      service.audit(prompt,'router','ai-route',f,{intent:intent.intent});
      if(intent.intent==='create_task')return {workflow:'action',filters:f,answer:'Please confirm this demo task.',proposal:service.propose({type:'create_task',projectId:f.project,title:intent.title},prompt)};
      const question={financial:'Show financial performance',projects:'Show projects',audit:'Show audit history'}[intent.intent];
      return {...service.command(question,f),routing:'gemini'};
    } catch {
      service.audit(prompt,'router','ai-unavailable',{}, {fallback:'local'},'failed');
      return {...local,notice:'External text interpretation is unavailable. The local example commands still work.'};
    }
  };
}
function createVoiceHandler(service) {
  return function voice(body) {
    if(!body || !body.args || !body.call?.call_id)throw new UserError('Expected the signed function envelope.');
    const args=body.args;
    if(body.name==='jarvis_query') {
      if(!['financial','projects','audit','knowledge'].includes(args.intent))throw new UserError('Unknown voice query.');
      const question={financial:'Show financial performance',projects:'Show projects',audit:'Show audit history',knowledge:args.question || 'Tell me about BITC'}[args.intent];
      const result=service.command(question,args.filters || {});
      return {answer:result.answer,filters:result.filters,mode:'controlled-demo',report:result.report ? {revenue:result.report.revenue,expense:result.report.expense,profit:result.report.profit,margin:result.report.margin}:undefined,projects:result.projects?.map(p=>({id:p.id,name:p.name,progress:p.progress,delayDays:p.delayDays,status:p.status})),audit:result.audit?.slice(0,5)};
    }
    if(body.name==='jarvis_propose_task') {
      const proposal=service.propose({type:'create_task',projectId:args.projectId,title:args.title},'Voice review task proposal');
      service.bindVoiceProposal(proposal.token,body.call.call_id);
      return {...proposal,mode:'controlled-demo',answer:'Ask the user to confirm this task before executing it.'};
    }
    if(body.name==='jarvis_confirm_task') {
      service.checkVoiceProposal(args.token,body.call.call_id);
      const result=service.execute({token:args.token,confirmed:args.confirmed===true,requestId:`voice-${args.token}`});
      return {...result,answer:`Demo task saved: ${result.task.title}.`};
    }
    throw new UserError('Unknown voice function.');
  };
}
module.exports={createCommandHandler,createVoiceHandler,intentSchema};
